package com.example.ADVprograming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdVprogramingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdVprogramingApplication.class, args);
	}

}
